
package ejemplo.de.concaquetenar;


public class EjemploDeConcaquetenar {
 
    
    public static void main(String[] args) {
          System.out.println("hola mundo   ");
          System.out.println("prueba   ");
          
          String nombre;
          String texto;
          
          nombre = "Ejemplo de concatenar dos variables...... ";
          
          System.out.println(nombre + "texto");
    }
    
}
