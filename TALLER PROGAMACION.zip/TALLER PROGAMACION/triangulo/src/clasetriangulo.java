
public class clasetriangulo {
     public static double area_del_triangulo(int a, int b){
        double t;
        t = (a*b)/2;
        return t;
}
